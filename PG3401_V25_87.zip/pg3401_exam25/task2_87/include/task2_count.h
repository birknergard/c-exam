/* TASK 2 COUNT HEADER FILE
 * AUTHOR: 87
 * DESCRIPTION: Header file for main program for this submission.
 * */
#include <stdio.h>
#include <stdlib.h>

#ifndef ___TASK2_COUNT_H___
#define ___TASK2_COUNT_H___

int Task2_CountEachCharacter(FILE * fFileDescriptor, char aCountArray[26]);

#endif /* ___TASK2_COUNT_H___  */
