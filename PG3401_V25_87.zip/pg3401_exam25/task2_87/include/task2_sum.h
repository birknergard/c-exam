/* TASK 2 SUM HEADER FILE
 * AUTHOR: 87
 * DESCRIPTION: Header file for main program for this submission.
 * */
#ifndef ___TASK2_SUM_H___
#define ___TASK2_SUM_H___

#include <stdio.h>

int Task2_SizeAndSumOfCharacters(FILE* fFileDescriptor, int* piSizeOfFile, int* piSumOfCharacters);

#endif /* ___TASK2_SUM_H___  */
